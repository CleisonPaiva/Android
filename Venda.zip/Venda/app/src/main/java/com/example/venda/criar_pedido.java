package com.example.venda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class criar_pedido extends AppCompatActivity  {

    private static final String FILE_NAME = "Cria_Pedido.txt";


    EditText mEditText1;
    EditText mEditText2;
    EditText mEditText3;
    EditText mEditText4;
    EditText mEditText5;
    EditText mEditText6;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_pedido);

        mEditText1 = findViewById(R.id.editText10);
        mEditText2 = findViewById(R.id.editText12);
        mEditText3 = findViewById(R.id.editText13);
        mEditText4 = findViewById(R.id.editText14);
        mEditText5 = findViewById(R.id.editText15);
        mEditText6 = findViewById(R.id.editText16);

    }
    public void numero(View view) {
        Random rand = new Random();
        int number = rand.nextInt(99999) + 11111;
        EditText mytext = (EditText) findViewById(R.id.editText16);
        String mystring = String.valueOf(number);
        mytext.setText(mystring);

    }
    public void cria_pedido(View view) throws JSONException {

        String text1 = mEditText1.getText().toString();
        String text2 = mEditText2.getText().toString();
        String text3 = mEditText3.getText().toString();
        String text4 = mEditText4.getText().toString();
        String text5 = mEditText5.getText().toString();
        String text6 = mEditText6.getText().toString();








        try {
            JSONObject jsonObject = new JSONObject();
            JSONArray dados = new JSONArray();

            JSONObject obj = new JSONObject();
            obj.put("Cod_Produto", text1);
            obj.put("Produto", text2);
            obj.put("Quantidade", text3);
            obj.put("Estoque", text4);
            obj.put("Valor", text5);
            obj.put("Num_pedido", text6);


            dados.put(obj);
            jsonObject.put("dados", dados);
            FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_APPEND);
            PrintWriter writer = new PrintWriter(fos);
            writer.println(jsonObject.toString());
            writer.flush();
            writer.close();
            fos.close();


            Toast.makeText(this, "Pedido Efetuado" ,
                    Toast.LENGTH_LONG).show();

        } catch (IOException e) {
            Log.e("Erro", e.getMessage());


        }
    }



}
