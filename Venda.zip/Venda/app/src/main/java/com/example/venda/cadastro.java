package com.example.venda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class cadastro<textView> extends AppCompatActivity {
    private static final String FILE_NAME = "Cria_Pedido.txt";

    TextView mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);


    }


    public void criar(View view) {
        Intent intent = new Intent(this, criar_pedido.class);
        startActivity(intent);
    }
    public void adicionar(View view) {
        Intent intent = new Intent(this, addproduto.class);
        startActivity(intent);
    }
    public void load(View view) {
       // mEditText = findViewById(R.id.text);
        TextView textView1=(TextView)findViewById(R.id.textView1);
        try{
            JSONObject emp=(new JSONObject(FILE_NAME)).getJSONObject("dados");
            String empname=emp.getString("Num_pedido");


            String str="Employee Name:"+empname+"\n"+"Employee Salary:";
            textView1.setText(str);

        }catch (Exception e) {e.printStackTrace();}

    }
}
       // FileInputStream fis = null;
        //mEditText = findViewById(R.id.text);
       /* try {

        /* fis = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text ="Num_pedido";

            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }

            mEditText.setText(sb.toString());

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }}*/

